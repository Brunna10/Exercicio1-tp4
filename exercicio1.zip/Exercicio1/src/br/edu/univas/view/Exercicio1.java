package br.edu.univas.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Exercicio1 extends JFrame {
	
	private JPanel content;
	
	public Exercicio1 (){
		this.setTitle("Exercico1");
		this.setSize(450,450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);;
		this.setLocationRelativeTo(null);
		initialize ();
	}
	
	private void initialize (){
		content = new JPanel();
		GridBagLayout gbc = new GridBagLayout();
		content.setLayout(gbc);
		this.setContentPane(content);
		
		GridBagConstraints constraints = new GridBagConstraints();
		
		JLabel nameLabel = new JLabel();
		nameLabel.setText("Nome");
		constraints.gridx = 0;
		constraints.gridy = 0;
		content.add(nameLabel, constraints);
		
		JTextField nameTextField = new JTextField();
		constraints.gridx = 1;
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.weightx = 1.0;
		content.add(nameTextField, constraints);
		
		JLabel celularLabel = new JLabel();
		celularLabel.setText("Celular");
		constraints.gridx = 0;
		constraints.gridy = 1;
		content.add(celularLabel, constraints);
		
		JTextField celularTextField = new JTextField();
		constraints.gridx= 1;
		constraints.weightx = 1.0;
		content.add(celularTextField, constraints);
		
		JLabel telefoneLabel = new JLabel();
		telefoneLabel.setText("Telefone");
		constraints.gridx = 0;
		constraints.gridy = 2;
		content.add(telefoneLabel, constraints);
		
		JTextField telefoneTextField = new JTextField();
		constraints.gridx= 1;
		constraints.weightx = 1.5;
		content.add(telefoneTextField, constraints);
		
		JLabel ruaLabel = new JLabel();
		ruaLabel.setText("Rua");
		constraints.gridx = 0;
		constraints.gridy = 3;
		content.add(ruaLabel, constraints);
		
		JTextField ruaTextField = new JTextField();
		constraints.gridx = 1;
		constraints.gridy = 1;
		content.add(ruaTextField, constraints);
		
		JLabel numeroLabel = new JLabel();
		numeroLabel.setText("N�");
		constraints.gridx = 0;
		constraints.gridy = 4;
		content.add(numeroLabel, constraints);
		
		JTextField numeroTextField = new JTextField();
		constraints.gridx = 1;
		constraints.weightx = 1;
		content.add(numeroTextField,constraints);
		
		JLabel bairroLabel = new JLabel();
		bairroLabel.setText("Bairro");
		constraints.gridx = 1;
		constraints.gridy = 4;
		content.add(bairroLabel, constraints);
		
		JTextField bairroTextField = new JTextField();
		constraints.gridx = 1;
		constraints.weightx = 1.5;
		content.add(bairroTextField, constraints);
		
		JButton addButton = new JButton();
		addButton.setText("Salvar");
		constraints.gridx = 0;
		constraints.gridx = 2;
		constraints.fill = GridBagConstraints.NONE;
		constraints.gridheight = 2;
		constraints.anchor = GridBagConstraints.CENTER;
		content.add(addButton, constraints);
		
		
		
	}

}
