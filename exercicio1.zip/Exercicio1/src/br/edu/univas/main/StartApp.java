package br.edu.univas.main;

import javax.swing.JFrame;

import br.edu.univas.view.Exercicio1;

public class StartApp {

	public static void main(String[] args) {
		JFrame Exercicio1 = new Exercicio1();
		Exercicio1.setVisible(true);
	}
}
